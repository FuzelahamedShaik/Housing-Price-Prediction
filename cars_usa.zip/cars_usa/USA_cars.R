cars <- read.csv("USA_cars_datasets.csv")
cars <- cars[2:ncol(cars)]

#any(is.na(cars)) no NA values

up_brand <- function(bnd){
  bnd <- as.character(bnd)
  if(bnd=="harley-davidson" | bnd=="acura" | bnd=="jaguar" | bnd=="lexus" | bnd=="lincoln" | bnd=="maserati" | bnd=="mazda" | bnd=="ram" | bnd=="toyota"){
    return("others")
  }else{
    return(bnd)
  }
}
cars$brand <- sapply(cars$brand,up_brand)
cars$brand <- factor(cars$brand)
table(cars$brand)
c1 <- cars[1:7]
c2 <- cars[10:12]
new_cars <- data.frame(c1,c2)

up_col <- function(col){
  col <- as.character(col)
  if(col=="black" | col=="blue" | col=="brown" | col=="charcoal" | col=="gold" | col=="gray" | col=="green" | col=="magnetic metallic" | col=="orange" | col=="red" | col=="silver" | col=="white" | col=="yellow"){
    return(col)
  }else if(col=="no_color"){
    return(NA)
  }else{
    return("others")
  }
}
new_cars$color <- sapply(new_cars$color,up_col)
new_cars$color <- factor(new_cars$color)
table(new_cars$color)

library(Amelia)
new_cars <- na.omit(new_cars)
missmap(new_cars)

table(new_cars$condition)
up_con <- function(con){
  con <- as.character(con)
  if(con=="Listing Expired"){
    return(NA)
  }else{
    return(con)
  }
}
new_cars$condition <- sapply(new_cars$condition,up_con)
new_cars$condition <- factor(new_cars$condition)
new_cars <- na.omit(new_cars)


library(ggplot2)
pl <- ggplot(new_cars,aes(brand)) + geom_bar(aes(fill=factor(title_status))) + theme_bw()
#print(pl)
pl2 <- ggplot(new_cars,aes(brand,price)) + geom_point(aes(color=factor(title_status)),size=4,alpha=0.5) + theme_bw()
#print(pl2)
pl3 <- ggplot(new_cars,aes(factor(color))) + geom_bar(aes(fill=factor(title_status))) + theme_bw()
#print(pl3)
pl4 <- ggplot(new_cars,aes(factor(condition),price)) + geom_point(aes(color=factor(title_status)),size=4,alpha=0.4) + theme_bw()
#print(pl4)
pl5 <- ggplot(new_cars,aes(title_status)) + geom_bar(aes(fill=country),position="dodge") + theme_bw()
#print(pl5)
pl6 <- ggplot(new_cars,aes(state)) + geom_bar(aes(fill=factor(title_status))) + theme_bw()
#print(pl6)
pl7 <- ggplot(new_cars,aes(state)) + geom_bar(aes(fill=factor(country))) + theme_bw()
#print(pl7)
pl8 <- ggplot(new_cars,aes(title_status)) + geom_bar(fill="blue") + theme_bw()
#print(pl8)

c1 <- new_cars[1:8]
c2 <- new_cars$condition
new_cars <- data.frame(c1,c2)

library(caTools)
set.seed(101)
sample <- sample.split(new_cars$title_status,SplitRatio = 0.8)
train <- subset(new_cars,sample==T)
test <- subset(new_cars,sample==F)

#I am using logistic regression algorithm to predict the title_status because it will take less time to compute.
log.model <- glm(title_status ~ price,family = binomial(logit),train)

test$prediction <- predict(log.model,newdata=test,type="response")
table(test$title_status,test$prediction>0.5)
accuracy = (449+25)/(449+25+2+8)
recall = 449/(449+2)
precision = 449/(449+8)










